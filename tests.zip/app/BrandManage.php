<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BrandManage extends Model
{
    //
}
