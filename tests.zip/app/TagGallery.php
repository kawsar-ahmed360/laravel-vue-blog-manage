<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TagGallery extends Model
{
    //
}
