<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SizeManage extends Model
{
    //
}
